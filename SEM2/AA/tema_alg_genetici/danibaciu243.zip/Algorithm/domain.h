//
// Created by danib on 3/19/2022.
//

#ifndef TEMA_ALG_GENETICI_DOMAIN_H
#define TEMA_ALG_GENETICI_DOMAIN_H

struct domainType{
    int a, b;
};

#endif //TEMA_ALG_GENETICI_DOMAIN_H
